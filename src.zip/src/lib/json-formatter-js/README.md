Based on https://github.com/mohsen1/json-formatter-js

Compiled by Michoel Chaikin (micholi@gmail.com) for easy use in browser